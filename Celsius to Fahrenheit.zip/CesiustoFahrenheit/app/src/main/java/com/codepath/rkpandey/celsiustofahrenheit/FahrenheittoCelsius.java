package com.codepath.rkpandey.celsiustofahrenheit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FahrenheittoCelsius extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fahrenheitto_celsius);
    }
}
